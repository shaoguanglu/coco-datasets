
Chess Sample - v1 2021-02-19 1:55pm
==============================

This dataset was exported via roboflow.ai on February 19, 2021 at 5:56 AM GMT

It includes 18 images.
Pieces are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)
* Grayscale (CRT phosphor)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Randomly crop between 0 and 30 percent of the image
* Random rotation of between -5 and +5 degrees
* Random brigthness adjustment of between -25 and +25 percent
* Random exposure adjustment of between -25 and +25 percent
* Salt and pepper noise was applied to 2 percent of pixels


